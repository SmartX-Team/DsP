TARGET=$1

INSTALLER_PATH=/home/tein/auto_vp_installer
POSTSCRIPTS_DIR=$INSTALLER_PATH/scripts/post_install_scripts
REPO_DIR=/usr/share/maas/web/static/maasrepo
REPO_URL='http://210.114.90.8/MAAS/static/maasrepo'
VP_DESIGN=$INSTALLER_PATH/conf/PLAYGROUND_DESIGN

echo "Enter the prepare_devstack.sh"
cp $POSTSCRIPTS_DIR/openstack_install/devstack/devstack_common.sh $REPO_DIR/postscripts/service/${TARGET}_devstack_common.sh

echo "wget -O /root/devstack_common.sh $REPO_URL/postscripts/service/${TARGET}_devstack_common.sh" >> $REPO_DIR/postscripts/base/${TARGET}.sh
echo "bash /root/devstack_common.sh" >> $REPO_DIR/postscripts/base/${TARGET}.sh


OPENSTACK_MODE=`cat $VP_DESIGN | sed -e "/TARGET_NODES/d" -ne "/$TARGET/,/}/p" | grep OPENSTACK_MODE | sed -e "s/OPENSTACK_MODE://g"`
echo $OPENSTACK_MODE


if [ ${OPENSTACK_MODE} == Compute ]; then
        echo "Prepare Compute Node"
        CONTROLLER_NODE=`cat $VP_DESIGN | sed -e "/TARGET_NODES/d" -ne "/$TARGET/,/}/p" | grep OPENSTACK_CONTROLLER |sed -e "s/OPENSTACK_CONTROLLER://g"`
        cp $POSTSCRIPTS_DIR/openstack_install/devstack/devstack_install_compute.sh $REPO_DIR/postscripts/service/${TARGET}_devstack_install.sh
        bash $POSTSCRIPTS_DIR/openstack_install/devstack/make_local_conf.sh $TARGET "COMPUTE"  $CONTROLLER_NODE

else
        echo "Prepare Controller Node"

        cp $POSTSCRIPTS_DIR/openstack_install/devstack/devstack_install_controller.sh $REPO_DIR/postscripts/service/${TARGET}_devstack_install.sh
        bash $POSTSCRIPTS_DIR/openstack_install/devstack/make_local_conf.sh $TARGET "CONTROLLER"
fi

chmod 755 $REPO_DIR/postscripts/service/${TARGET}_devstack_common.sh $REPO_DIR/postscripts/service/${TARGET}_devstack_install.sh

